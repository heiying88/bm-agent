import{a4 as s}from"./vendor-mermaid-7_J_sMBJ.js";var t,e=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{e as I};
